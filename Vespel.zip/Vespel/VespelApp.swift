//
//  VespelApp.swift
//  Vespel
//
//  Created by Sandesh Raj on 04/04/25.
//

import SwiftUI

@main
struct VespelApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
