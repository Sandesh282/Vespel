//
//  ContentView.swift
//  Vespel
//
//  Created by Sandesh Raj on 04/04/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem { Label("Home", systemImage: "house") }
            
            PlayerView()
                .tabItem { Label("Player", systemImage: "music.note") }
            
            LibraryView()
                .tabItem { Label("Library", systemImage: "books.vertical") }
        }
    }
}

#Preview {
    ContentView()
}
