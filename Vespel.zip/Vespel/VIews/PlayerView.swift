import SwiftUI


struct PlayerView: View {
    @ObservedObject var audioManager = AudioManager.shared
    
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: audioManager.currentSong?.artwork ?? "music.note")
                .font(.system(size: 200))
                .padding()
            
            VStack {
                Text(audioManager.currentSong?.title ?? "No Song")
                    .font(.title.bold())
                Text(audioManager.currentSong?.artist ?? "—")
                    .foregroundColor(.gray)
            }
            
            ProgressView(value: 0.5)
                .padding()
            
            HStack(spacing: 40) {
                
                Button(action: {
                    // Add backward skip action
                }) {
                    Image(systemName: "backward.fill")
                        .font(.system(size: 40))
                }

                
                Button(action: {
                    audioManager.isPlaying.toggle()
                }) {
                    Image(systemName: audioManager.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 40))
                }

                
                Button(action: {
                    // Add forward skip action
                }) {
                    Image(systemName: "forward.fill")
                        .font(.system(size: 40))
                }
            }

        }
        .padding()
    }
}

#Preview {
    PlayerView()
}
