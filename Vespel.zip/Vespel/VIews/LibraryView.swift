import SwiftUI

struct LibraryView: View {
    @ObservedObject var audioManager = AudioManager.shared
    @State private var searchText = ""
    
    var filteredSongs: [Song] {
        if searchText.isEmpty {
            return MockData.songs
        } else {
            return MockData.songs.filter {
                $0.title.localizedCaseInsensitiveContains(searchText) ||
                $0.artist.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
    
    var body: some View {
        NavigationStack {
            List {
                
                Section(header: Text("Recently Played")) {
                    ForEach(MockData.songs.prefix(3)) { song in
                        SongRow(song: song, isPlaying: isCurrentSong(song))
                            .onTapGesture { audioManager.play(song: song) }
                    }
                }
                
                Section(header: Text("All Songs")) {
                    ForEach(filteredSongs) { song in
                        SongRow(song: song, isPlaying: isCurrentSong(song))
                            .onTapGesture { audioManager.play(song: song) }
                    }
                }
            }
            .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always))
            .navigationTitle("Library")
            .overlay(alignment: .bottom) { MiniPlayerBar() }
        }
    }
    
    private func isCurrentSong(_ song: Song) -> Bool {
        audioManager.currentSong?.id == song.id && audioManager.isPlaying
    }
}

struct SongRow: View {
    let song: Song
    let isPlaying: Bool
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: song.artwork)
                .font(.title3)
                .foregroundColor(isPlaying ? .purple : .primary)
            
            VStack(alignment: .leading) {
                Text(song.title)
                    .fontWeight(.medium)
                    .lineLimit(1)
                Text(song.artist)
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            Text(formattedDuration)
                .font(.caption)
                .foregroundColor(.gray)
            
            if isPlaying {
                Image(systemName: "waveform")
                    .foregroundColor(.purple)
            }
        }
        .padding(.vertical, 8)
    }
    
    private var formattedDuration: String {
        let minutes = Int(song.duration) / 60
        let seconds = Int(song.duration) % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
}

#Preview {
    LibraryView()
        .environmentObject(AudioManager.shared)
}
