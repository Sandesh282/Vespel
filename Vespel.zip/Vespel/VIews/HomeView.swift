import SwiftUI

struct HomeView: View {
    @StateObject var audioManager = AudioManager.shared
    
    var body: some View {
        NavigationStack {
            List(MockData.songs) { song in
                Button(action: { audioManager.play(song: song) }) {
                    HStack {
                        Image(systemName: song.artwork)
                        Text(song.title)
                    }
                }
            }
            .navigationTitle("Home")
            .overlay(alignment: .bottom) { MiniPlayerBar() }
        }
    }
}

#Preview{
    HomeView()
}
