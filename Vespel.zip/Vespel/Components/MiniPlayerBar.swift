import SwiftUI

struct MiniPlayerBar: View {
    @ObservedObject var audioManager = AudioManager.shared
    
    var body: some View {
        if let song = audioManager.currentSong {
            HStack {
                Image(systemName: song.artwork)
                    .font(.title2)
                
                VStack(alignment: .leading) {
                    Text(song.title).fontWeight(.medium)
                    Text(song.artist).foregroundColor(.gray)
                }
                
                Spacer()
                
                Button(action: { audioManager.togglePlay() }) {
                    Image(systemName: audioManager.isPlaying ? "pause.fill" : "play.fill")
                }
            }
            .padding()
            .background(.thinMaterial)
            .cornerRadius(12)
            .padding(.horizontal)
        }
    }
}

#Preview {
    MiniPlayerBar()
}
